# Elite Premier League 2026 — website

Static site (HTML + JavaScript) on **Firebase Hosting**, with **Firebase Authentication** and **Cloud Firestore**.
No build step. Everything the site serves is in `public/`.

## Try it first (no setup)
```
cd public
python3 -m http.server 8000      # then open http://localhost:8000
```
While `js/config.js` has no Firebase keys the site runs in **DEMO MODE** (data lives only in your own browser, a yellow banner shows).
Demo admin: go to `/#/admin`, use `solomonoladimeji18@gmail.com` and any password.

## Go live (all free — Spark plan, no card)

1. **Create the project.** https://console.firebase.google.com → Add project. The Project ID becomes your address
   (`elite-premier-league` → `https://elite-premier-league.web.app`). Google Analytics can stay off.
2. **Turn on sign-in.** Build → Authentication → Get started → Sign-in method:
   - enable **Google** (players) — pick a support email
   - enable **Email/Password** (admin)
   Then Authentication → Users → **Add user**: email `solomonoladimeji18@gmail.com`, password of your choice
   (**change `solomon` to something strong before launch**).
   Authentication → Settings → Authorized domains: make sure `your-project-id.web.app` is listed (it is by default).
3. **Add the keys.** Project settings (gear) → General → Your apps → **Web app** (`</>`) → register → copy the `firebaseConfig`
   values into `FIREBASE_CONFIG` in `public/js/config.js`.
4. **Create the database.** Build → Firestore Database → Create database → production mode → region `eur3` (or nearest).
5. **(Optional) Email alerts to the admin.** https://www.emailjs.com (free) →
   - Email Services → Add service → Gmail (connect `solomonoladimeji18@gmail.com`) → copy the **Service ID**
   - Email Templates → Create. To: `{{to_email}}`. Subject: `New registration: {{player_name}} ({{team}})`.
     Body: `{{player_name}} · {{player_phone}} · {{player_email}} registered for {{team}} at {{registered_at}}. Review and approve: {{admin_link}}`
     → copy the **Template ID**
   - Account → General → **Public Key**
   Paste the three values into `EMAILJS` in `public/js/config.js`.
   (Photos are viewed in the admin panel — Gmail does not show images embedded in emails.)
6. **Deploy.**
   ```
   npm install -g firebase-tools
   firebase login
   firebase use the-elite-league   # already set in .firebaserc
   firebase deploy             # publishes the site AND the security rules (firestore.rules)
   ```
   Live at `https://<project-id>.web.app`. Open `/#/admin`, sign in, then **Fixtures → Load the 16 poster fixtures** and pick the match day.

## How it works
- **Players** sign in with Google, fill name / phone / team / **compulsory photo**. One registration per Google account.
  The photo is shrunk in the browser (320 px JPEG, ~15 KB) and stored in the database, so no paid file storage is needed.
- **Admin** (only `solomonoladimeji18@gmail.com`) approves or rejects. A team with **8 approved players is closed**:
  its radio button is disabled on the form and the admin cannot approve a 9th player.
- Fixtures can be scheduled, edited and deleted; results (and goal scorers) are entered after each match.
  The table and stats are calculated from confirmed results.
- Security is enforced by `firestore.rules`, not just by the page: only the admin can write players, fixtures and results;
  players can only create/update their own *pending* registration.

## Things to know
- Team badges are original designs in club colours (real crests are trademarked). To use real crests, drop PNGs in
  `public/img/` and change `badge()` in `public/js/teams.js`.
- Rules text is in `public/js/pages.js` (`rules()`), including the points system (3/1/0) — edit to match your real rules.
- `og:image` in `public/index.html` should be a full URL once you know your address, e.g. `https://<project-id>.web.app/img/og.png`.
- To add another admin: add the email in `ADMIN_EMAIL` handling (`js/config.js`, `js/backend-firebase.js`) **and** in `firestore.rules`.
