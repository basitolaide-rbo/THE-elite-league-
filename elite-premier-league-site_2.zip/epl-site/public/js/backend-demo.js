// DEMO backend: everything is kept in this browser's localStorage so the site can be tried
// without Firebase. It is replaced automatically as soon as real Firebase keys are in config.js.
import { ADMIN_EMAIL, LEAGUE } from "./config.js";

export const mode = "demo";
const K = "epl_demo_v1";
const mem = { data: null };

function load() {
  if (mem.data) return mem.data;
  try { mem.data = JSON.parse(localStorage.getItem(K)) || null; } catch { mem.data = null; }
  if (!mem.data) mem.data = { players: {}, registrations: {}, fixtures: {}, user: null };
  return mem.data;
}
function save() { try { localStorage.setItem(K, JSON.stringify(mem.data)); } catch { /* storage full or blocked */ } }
const listeners = new Set();
const emit = () => { const u = load().user; listeners.forEach((cb) => cb(u)); };
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

export function onAuth(cb) {
  listeners.add(cb);
  setTimeout(() => cb(load().user), 0);
  return () => listeners.delete(cb);
}

export async function signInGoogle() {
  const email = (window.prompt("DEMO MODE — type any Gmail address to pretend to sign in with Google:", "player@gmail.com") || "").trim().toLowerCase();
  if (!email) return;
  const d = load();
  d.user = { uid: "demo-" + email.replace(/[^a-z0-9]/g, ""), email, name: email.split("@")[0], isAdmin: email === ADMIN_EMAIL.toLowerCase() };
  save(); emit();
}

export async function signInAdmin(email, password) {
  if (email.trim().toLowerCase() !== ADMIN_EMAIL.toLowerCase()) throw new Error("This account is not allowed in the admin panel.");
  if (!password) throw new Error("Type the password.");
  const d = load();
  d.user = { uid: "demo-admin", email: ADMIN_EMAIL.toLowerCase(), name: "Admin", isAdmin: true };
  save(); emit();
}

export async function signOut() { const d = load(); d.user = null; save(); emit(); }

const vals = (o) => Object.entries(o).map(([id, v]) => ({ id, ...v }));

export async function getPlayers() { return vals(load().players).map((p) => ({ ...p, uid: p.id })); }
export async function getMyRegistration(u) { const r = load().registrations[u]; return r ? { uid: u, ...r } : null; }
export async function getRegistrations() { return vals(load().registrations).map((r) => ({ ...r, uid: r.id })); }

export async function submitRegistration(user, data) {
  const d = load();
  const reg = { uid: user.uid, email: user.email, googleName: user.name, name: data.name, phone: data.phone, team: data.team, photo: data.photo, status: "pending", createdAt: Date.now() };
  d.registrations[user.uid] = reg; save();
  return reg;
}

export async function approveRegistration(u) {
  const d = load();
  const r = d.registrations[u];
  if (!r) throw new Error("Registration not found.");
  const count = Object.entries(d.players).filter(([id, p]) => p.team === r.team && id !== u).length;
  if (count >= LEAGUE.playersPerTeam) throw new Error(`That team already has ${LEAGUE.playersPerTeam} players. Reject this registration or remove a player first.`);
  d.players[u] = { name: r.name, team: r.team, photo: r.photo, approvedAt: Date.now() };
  r.status = "approved"; r.decidedAt = Date.now(); save();
}

export async function rejectRegistration(u, reason = "") {
  const d = load();
  if (d.registrations[u]) Object.assign(d.registrations[u], { status: "rejected", reason, decidedAt: Date.now() });
  delete d.players[u]; save();
}

export async function removePlayer(u) {
  const d = load();
  delete d.players[u];
  if (d.registrations[u]) Object.assign(d.registrations[u], { status: "removed", decidedAt: Date.now() });
  save();
}

export async function getFixtures() { return vals(load().fixtures); }

export async function saveFixture(fx) {
  const d = load();
  const id = fx.id || uid();
  const { id: _omit, ...rest } = fx;
  d.fixtures[id] = { ...(d.fixtures[id] || {}), ...rest };
  save();
  return id;
}

export async function deleteFixture(id) { delete load().fixtures[id]; save(); }

export async function seedFixtures(list) {
  const d = load();
  list.forEach((fx) => { d.fixtures[uid()] = fx; });
  save();
}
