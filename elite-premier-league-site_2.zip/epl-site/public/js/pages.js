import * as data from "./data.js";
import { TEAMS, teamById, badge } from "./teams.js";
import { LEAGUE } from "./config.js";
import { notifyAdmin } from "./email.js";
import {
  esc, $, $$, toast, fmtDate, fmtTime, dayKey, teamLabel, sortFixtures, computeTable, topScorers,
  squadOf, compressPhoto, safeImg, photoTag, roundName
} from "./ui.js";

const MAX = LEAGUE.playersPerTeam;

// ---------- shared pieces ----------
export function fixtureCard(f) {
  const done = f.status === "finished";
  const mid = done
    ? `<div class="score" aria-label="Final score ${f.homeScore} to ${f.awayScore}">${f.homeScore} – ${f.awayScore}</div><div class="small muted">FT</div>`
    : `<div class="score">${f.kickoff ? esc(fmtTime(f.kickoff)) : "TBC"}</div><div class="small muted">vs</div>`;
  const sc = (f.scorers || []);
  const side = (id) => sc.filter((s) => s.teamId === id).map((s) => `${esc(s.name)}${s.minute ? ` ${esc(s.minute)}'` : ""}`).join(", ");
  return `<div class="fx">
    <div class="t h">${teamLabel(f.homeId, 30)}</div>
    <div class="mid">${mid}</div>
    <div class="t">${teamLabel(f.awayId, 30)}</div>
    <div class="meta">${f.kickoff ? esc(fmtDate(f.kickoff)) : ""}${f.venue ? " · " + esc(f.venue) : ""}</div>
    ${done && sc.length ? `<div class="gs"><span>⚽ ${side(f.homeId) || "—"}</span><span>${side(f.awayId) || "—"} ⚽</span></div>` : ""}
  </div>`;
}

export function groupedFixtures(list) {
  const fx = sortFixtures(list);
  if (!fx.length) return `<div class="empty">No fixtures yet. They will appear here once the committee schedules them.</div>`;
  const groups = new Map();
  fx.forEach((f) => {
    const key = f.round ? `${dayKey(f.kickoff || "2000-01-01")}|r${f.round}` : `${dayKey(f.kickoff || "2000-01-01")}`;
    if (!groups.has(key)) groups.set(key, { round: f.round, day: f.kickoff, items: [] });
    groups.get(key).items.push(f);
  });
  return [...groups.values()].map((g) => `<section class="round">
    <h3>${g.round ? esc(roundName(g.round)) : esc(g.day ? fmtDate(g.day) : "Fixtures")}
      <small>${g.day ? esc(fmtDate(g.day)) : ""}${g.round && g.items[0].kickoff ? " · " + esc(fmtTime(g.items[0].kickoff)) : ""}</small></h3>
    ${g.items.map(fixtureCard).join("")}</section>`).join("");
}

const statusPill = (s) => ({
  pending: `<span class="pill warn">Pending approval</span>`,
  approved: `<span class="pill ok">Approved</span>`,
  rejected: `<span class="pill bad">Not approved</span>`,
  removed: `<span class="pill bad">Removed</span>`
}[s] || "");

const signInBlock = (why) => `<div class="card" style="max-width:520px">
  <h3>Sign in to continue</h3>
  <p class="muted">${esc(why)}</p>
  <button class="btn" data-act="google">Sign in with Google</button>
</div>`;

function bindAuth(el, ctx) {
  $$('[data-act="google"]', el).forEach((b) => b.addEventListener("click", async () => {
    try { await data.signInGoogle(); } catch (e) { toast(e.message || "Sign-in failed.", true); }
  }));
  $$('[data-act="signout"]', el).forEach((b) => b.addEventListener("click", async () => { await data.signOut(); ctx.go("#/"); }));
}

// ---------- pages ----------
export async function home(el, ctx) {
  const [fixtures, players] = await Promise.all([data.getFixtures(), data.getPlayers()]);
  const finished = fixtures.filter((f) => f.status === "finished").length;
  const next = sortFixtures(fixtures).find((f) => f.status !== "finished");
  const full = TEAMS.filter((t) => squadOf(players, t.id).length >= MAX).length;
  el.innerHTML = `
  <section class="hero">
    <img src="img/logo.svg" alt="Elite Premier League crest">
    <h1>Elite Premier League</h1>
    <p>Eight clubs. Eight players each. One champion. Register your place, follow every fixture and watch the table move live.</p>
    <div class="btns"><a class="btn" href="#/register">Register to play</a><a class="btn ghost" href="#/fixtures">See fixtures</a></div>
  </section>
  <div class="grid g4" style="margin-bottom:22px">
    <div class="card stat"><b>${TEAMS.length}</b><span>Teams</span></div>
    <div class="card stat"><b>${players.length}/${TEAMS.length * MAX}</b><span>Players registered</span></div>
    <div class="card stat"><b>${full}/${TEAMS.length}</b><span>Squads full</span></div>
    <div class="card stat"><b>${finished}/${fixtures.length}</b><span>Matches played</span></div>
  </div>
  ${next ? `<h2>Next match</h2>${fixtureCard(next)}` : ""}
  <h2 style="margin-top:22px">The teams</h2>
  <div class="grid g4">${TEAMS.map((t) => {
    const n = squadOf(players, t.id).length;
    return `<a class="card stat" style="text-decoration:none;color:inherit" href="#/teams">${badge(t.id, 56)}<div style="font-weight:700;margin-top:6px">${esc(t.name)}</div><span>${n >= MAX ? "Squad full" : `${n}/${MAX} players`}</span></a>`;
  }).join("")}</div>`;
}

export async function fixtures(el) {
  const list = await data.getFixtures();
  el.innerHTML = `<h2>Fixtures &amp; results</h2>${groupedFixtures(list)}`;
}

export async function table(el) {
  const rows = computeTable(await data.getFixtures());
  el.innerHTML = `<h2>League table</h2>
  <div class="tablewrap"><table><thead><tr><th>#</th><th class="team">Team</th><th>P</th><th>W</th><th>D</th><th>L</th><th>GF</th><th>GA</th><th>GD</th><th>Pts</th></tr></thead>
  <tbody>${rows.map((r, i) => `<tr class="${i === 0 && r.p ? "p1" : ""}"><td>${i + 1}</td><td class="team">${badge(r.id, 28)}<span>${esc(teamById[r.id].name)}</span></td>
    <td>${r.p}</td><td>${r.w}</td><td>${r.d}</td><td>${r.l}</td><td>${r.gf}</td><td>${r.ga}</td><td>${r.gd > 0 ? "+" : ""}${r.gd}</td><td class="pts">${r.pts}</td></tr>`).join("")}</tbody></table></div>
  <p class="muted small" style="margin-top:10px">Win 3 points, draw 1, loss 0. Ties are split by goal difference, then goals scored. The table updates as soon as the committee confirms a result.</p>`;
}

export async function teams(el) {
  const players = await data.getPlayers();
  el.innerHTML = `<h2>Teams &amp; squads</h2><div class="grid g2">${TEAMS.map((t) => {
    const sq = squadOf(players, t.id);
    const slots = Array.from({ length: MAX }, (_, i) => sq[i]
      ? `<div class="pl">${photoTag(sq[i].photo, sq[i].name)}${esc(sq[i].name)}</div>`
      : `<div class="pl"><div class="ph">Open</div>&nbsp;</div>`).join("");
    return `<article class="card"><div class="teamhead">${badge(t.id, 46)}<div><h3>${esc(t.name)}</h3>
      <span class="pill ${sq.length >= MAX ? "ok" : ""}">${sq.length >= MAX ? "Squad full" : `${sq.length}/${MAX} players`}</span></div></div>
      <div class="squad">${slots}</div></article>`;
  }).join("")}</div>`;
}

export async function stats(el) {
  const list = await data.getFixtures();
  const scorers = topScorers(list);
  const table = computeTable(list).filter((r) => r.p);
  const goals = list.filter((f) => f.status === "finished").reduce((s, f) => s + f.homeScore + f.awayScore, 0);
  const played = list.filter((f) => f.status === "finished").length;
  const best = (key, dir) => [...table].sort((a, b) => dir * (a[key] - b[key]))[0];
  const atk = best("gf", -1), def = best("ga", 1);
  el.innerHTML = `<h2>Stats</h2>
  <div class="grid g4" style="margin-bottom:18px">
    <div class="card stat"><b>${played}</b><span>Matches played</span></div>
    <div class="card stat"><b>${goals}</b><span>Goals scored</span></div>
    <div class="card stat"><b>${played ? (goals / played).toFixed(1) : "0.0"}</b><span>Goals per match</span></div>
  </div>
  <div class="grid g2">
    <section class="card"><h3>Top scorers</h3>${scorers.length ? `<ol style="padding-left:20px;margin:8px 0 0">${scorers.slice(0, 10).map((s) => `<li style="margin:6px 0"><b>${esc(s.name)}</b> <span class="muted">· ${esc(teamById[s.teamId]?.name || "")}</span> <b style="float:right;color:var(--mint)">${s.goals}</b></li>`).join("")}</ol>` : `<p class="muted">No goals recorded yet.</p>`}</section>
    <section class="card"><h3>Team form</h3>${table.length ? `
      <p>Best attack: <b>${esc(teamById[atk.id].name)}</b> <span class="muted">(${atk.gf} goals)</span></p>
      <p>Best defence: <b>${esc(teamById[def.id].name)}</b> <span class="muted">(${def.ga} conceded)</span></p>
      <p>Leaders: <b>${esc(teamById[computeTable(list)[0].id].name)}</b></p>` : `<p class="muted">Stats appear after the first result.</p>`}</section>
  </div>`;
}

export function rules(el) {
  el.innerHTML = `<h2>Rules &amp; regulations</h2>
  <ol class="rules">
    <li><b>Teams.</b> Eight teams take part: ${TEAMS.map((t) => esc(t.name)).join(", ")}.</li>
    <li><b>Squads.</b> Each team has a maximum of <b>${MAX} players</b>. When a team has ${MAX} approved players it is closed and no one else can join it.</li>
    <li><b>Registration.</b> Every player registers once with their Google account, picks a team and uploads a clear face photo. The photo is compulsory.</li>
    <li><b>Approval.</b> A registration only counts once the league organiser has approved it. Until then it shows as “Pending”. The organiser may reject any registration.</li>
    <li><b>Match length.</b> Each match lasts ${LEAGUE.matchMinutes} minutes ${LEAGUE.matchSeconds} seconds. Matches follow each other with no transition time, from 07:45 AM to 12:00 PM on match day.</li>
    <li><b>Points.</b> Win 3 points, draw 1 point, loss 0.</li>
    <li><b>Table order.</b> Points, then goal difference, then goals scored.</li>
    <li><b>Results.</b> Scores and goal scorers are entered by the organiser after each match and are final once confirmed on this site.</li>
    <li><b>Prizes.</b> The team on top of the table lifts the Elite Premier League trophy.</li>
  </ol>
  <p class="muted small">The committee can change these rules at any time. Edit the list in <code>js/pages.js</code>.</p>`;
}

let deferred = null;
window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); deferred = e; });
export function install(el) {
  el.innerHTML = `<h2>Get the app</h2>
  <p class="muted">Put Elite Premier League on your home screen. It opens like an app, with no app store.</p>
  ${deferred ? `<p><button class="btn" id="inst">Install now</button></p>` : ""}
  <div class="grid g2">
    <div class="card"><h3>Android (Chrome)</h3><ol class="steps"><li>Open this site in Chrome.</li><li>Tap the ⋮ menu.</li><li>Tap “Install app” or “Add to Home screen”.</li><li>Tap Install.</li></ol></div>
    <div class="card"><h3>iPhone (Safari)</h3><ol class="steps"><li>Open this site in Safari.</li><li>Tap the Share button.</li><li>Tap “Add to Home Screen”.</li><li>Tap Add.</li></ol></div>
  </div>`;
  $("#inst", el)?.addEventListener("click", async () => { deferred.prompt(); await deferred.userChoice; deferred = null; });
}

// ---------- registration ----------
export async function register(el, ctx) {
  if (!ctx.user) {
    el.innerHTML = `<h2>Register to play</h2>${signInBlock("Sign in with your Google account to register. It takes about three minutes — have your phone camera ready for your photo.")}`;
    return bindAuth(el, ctx);
  }
  const [players, mine] = await Promise.all([data.getPlayers(), data.getMyRegistration(ctx.user.uid)]);
  if (mine && (mine.status === "pending" || mine.status === "approved")) {
    el.innerHTML = `<h2>Register to play</h2><div class="note ok">You already have a registration (${statusPill(mine.status)}). <a href="#/account">View My registration</a>.</div>`;
    return;
  }
  const count = (id) => squadOf(players, id).length;
  el.innerHTML = `<h2>Register to play</h2>
  ${mine && (mine.status === "rejected" || mine.status === "removed") ? `<div class="note warn" style="margin-bottom:14px">Your last registration was not approved${mine.reason ? `: ${esc(mine.reason)}` : ""}. You can submit a new one.</div>` : ""}
  <form class="f" id="regform" novalidate>
    <p class="muted" style="margin:0">Signed in as <b>${esc(ctx.user.email)}</b></p>
    <label>Full name<input type="text" name="name" required autocomplete="name" maxlength="60" value="${esc(ctx.user.name)}"></label>
    <label>Phone number<input type="tel" name="phone" required autocomplete="tel" inputmode="tel" maxlength="20" placeholder="08012345678"></label>
    <fieldset style="border:0;padding:0;margin:0"><legend style="font-weight:600;font-size:13px;margin-bottom:6px">Choose your team</legend>
      <div class="teamopt">${TEAMS.map((t) => {
        const n = count(t.id), full = n >= MAX;
        return `<label><input type="radio" name="team" value="${t.id}" ${full ? "disabled" : ""}><span class="o">${badge(t.id, 28)}<span>${esc(t.name)}<small>${full ? "Full — closed" : `${n}/${MAX} players`}</small></span></span></label>`;
      }).join("")}</div></fieldset>
    <div>
      <div style="font-weight:600;font-size:13px;margin-bottom:6px">Your photo <span style="color:var(--bad)">(required)</span></div>
      <div class="photo"><div class="prev" id="prev">No photo yet</div>
        <div><input type="file" id="photo" accept="image/*" capture="user" style="max-width:220px"><div class="small muted" style="margin-top:6px">A clear photo of your face. Use your phone camera.</div></div></div>
    </div>
    <div id="err" class="note bad" hidden></div>
    <button class="btn" type="submit" id="go">Submit registration</button>
    <p class="small muted" style="margin:0">After you submit, the organiser reviews your registration. You can check the result on “My registration”.</p>
  </form>`;
  let photo = "";
  $("#photo", el).addEventListener("change", async (e) => {
    const prev = $("#prev", el);
    try {
      photo = await compressPhoto(e.target.files[0]);
      prev.style.backgroundImage = `url(${photo})`; prev.textContent = ""; prev.classList.add("has");
    } catch (err) { photo = ""; prev.style.backgroundImage = ""; prev.classList.remove("has"); prev.textContent = "No photo yet"; toast(err.message, true); }
  });
  $("#regform", el).addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = e.target, err = $("#err", el);
    const name = f.name.value.trim(), phone = f.phone.value.trim(), team = (f.team.value || "");
    const problems = [];
    if (name.length < 3) problems.push("Enter your full name.");
    if (!/^[+0-9][0-9 +()-]{6,19}$/.test(phone)) problems.push("Enter a valid phone number.");
    if (!team) problems.push("Choose a team.");
    if (!photo) problems.push("Your photo is required.");
    if (problems.length) { err.hidden = false; err.innerHTML = problems.map(esc).join("<br>"); return; }
    err.hidden = true;
    const btn = $("#go", el); btn.disabled = true; btn.textContent = "Submitting…";
    try {
      const fresh = await data.getPlayers();
      if (squadOf(fresh, team).length >= MAX) throw new Error("That team has just become full. Please choose another team.");
      const reg = await data.submitRegistration(ctx.user, { name, phone, team, photo });
      notifyAdmin(reg);
      toast("Registration submitted. The organiser will review it.");
      ctx.go("#/account");
    } catch (ex) {
      btn.disabled = false; btn.textContent = "Submit registration";
      err.hidden = false; err.textContent = ex.message || "Something went wrong. Please try again.";
    }
  });
}

export async function account(el, ctx) {
  if (!ctx.user) {
    el.innerHTML = `<h2>My registration</h2>${signInBlock("Sign in with the Google account you registered with to check your status.")}`;
    return bindAuth(el, ctx);
  }
  const mine = await data.getMyRegistration(ctx.user.uid);
  const msg = {
    pending: "The organiser has your registration and will review it soon.",
    approved: "You're in! You now appear in your team's squad.",
    rejected: "Your registration was not approved.",
    removed: "You were removed from the squad. Contact the organiser if this is a mistake."
  };
  el.innerHTML = `<h2>My registration</h2>
  <p class="muted">Signed in as <b>${esc(ctx.user.email)}</b> · <button class="btn ghost sm" data-act="signout">Sign out</button></p>
  ${mine ? `<div class="card" style="max-width:520px"><div class="reg">
      ${safeImg(mine.photo) ? `<img src="${safeImg(mine.photo)}" alt="Your photo">` : ""}
      <div><h3>${esc(mine.name)}</h3><div style="display:flex;align-items:center;gap:8px;margin:6px 0">${badge(mine.team, 26)}<b>${esc(teamById[mine.team]?.name || mine.team)}</b></div>
      ${statusPill(mine.status)}<p class="small muted" style="margin:8px 0 0">${esc(msg[mine.status] || "")}${mine.reason ? " Reason: " + esc(mine.reason) : ""}</p></div></div></div>
    ${mine.status === "rejected" || mine.status === "removed" ? `<p><a class="btn" href="#/register">Register again</a></p>` : ""}`
    : `<div class="empty">You haven't registered yet.<br><br><a class="btn" href="#/register">Register to play</a></div>`}`;
  bindAuth(el, ctx);
}
