import * as data from "./data.js";
import { TEAMS, teamById, badge } from "./teams.js";
import { LEAGUE, ADMIN_EMAIL } from "./config.js";
import {
  esc, $, $$, toast, fmtDate, fmtTime, dayKey, timeValue, teamLabel, sortFixtures, squadOf,
  safeImg, photoTag, roundName, ROUND_NAMES
} from "./ui.js";

const MAX = LEAGUE.playersPerTeam;
let tab = "regs";

// The 16 matches from the official fixtures poster: 4 rounds of 4 games, each 63 min 45 s, no breaks, from 07:45.
const POSTER = [
  [["mun", "mci"], ["ars", "rma"], ["che", "bar"], ["liv", "bay"]],
  [["mun", "rma"], ["mci", "bar"], ["ars", "bay"], ["che", "liv"]],
  [["mun", "bar"], ["rma", "bay"], ["mci", "liv"], ["ars", "che"]],
  [["mun", "bay"], ["bar", "liv"], ["rma", "che"], ["mci", "ars"]]
];
const MATCH_SECONDS = LEAGUE.matchMinutes * 60 + LEAGUE.matchSeconds;
const START_SECONDS = 7 * 3600 + 45 * 60;
const pad = (n) => String(n).padStart(2, "0");
const hms = (s) => `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
export function posterFixtures(date) {
  return POSTER.flatMap((games, r) => games.map(([homeId, awayId]) => ({
    round: r + 1, homeId, awayId, venue: "TBA", status: "scheduled", homeScore: null, awayScore: null, scorers: [],
    kickoff: `${date}T${hms(START_SECONDS + r * MATCH_SECONDS)}+01:00`
  })));
}
const toKickoff = (date, time) => `${date}T${time.length === 5 ? time + ":00" : time}+01:00`;

function dialog(html, onMount) {
  const d = document.createElement("dialog");
  d.innerHTML = html;
  document.body.appendChild(d);
  d.addEventListener("close", () => d.remove());
  d.addEventListener("click", (e) => { if (e.target.matches("[data-close]")) d.close(); });
  d.showModal();
  onMount?.(d);
  return d;
}

export async function admin(el, ctx) {
  const u = ctx.user;
  if (!u || !u.isAdmin) return login(el, ctx);
  await panel(el, ctx);
}

function login(el, ctx) {
  const u = ctx.user;
  el.innerHTML = `<h2>Admin sign-in</h2>
  ${u && !u.isAdmin ? `<div class="note bad" style="max-width:420px;margin-bottom:14px"><b>Not authorised.</b> ${esc(u.email)} is not an admin account.
    <div style="margin-top:10px"><button class="btn ghost sm" id="so">Sign out</button></div></div>` : ""}
  <form class="f" id="lf" style="max-width:420px" autocomplete="on">
    <p class="muted" style="margin:0">Only the league organiser can enter this area.</p>
    <label>Email<input type="email" name="email" required autocomplete="username" value="${esc(ADMIN_EMAIL)}"></label>
    <label>Password<input type="password" name="password" required autocomplete="current-password"></label>
    <div id="err" class="note bad" hidden></div>
    <button class="btn" type="submit">Sign in</button>
    ${data.mode === "demo" ? `<p class="small muted" style="margin:0">Demo mode: any password works. In the live site the real password is checked by Firebase.</p>` : ""}
  </form>`;
  $("#so", el)?.addEventListener("click", () => data.signOut());
  $("#lf", el).addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = e.target, err = $("#err", el);
    try { err.hidden = true; await data.signInAdmin(f.email.value, f.password.value); }
    catch (ex) { err.hidden = false; err.textContent = ex.message; }
  });
}

async function panel(el, ctx) {
  const [regs, players, fixtures] = await Promise.all([data.getRegistrations(), data.getPlayers(), data.getFixtures()]);
  const pending = regs.filter((r) => r.status === "pending");
  const rerender = () => panel(el, ctx);
  const tabs = [["regs", `Registrations${pending.length ? `<span class="n">${pending.length}</span>` : ""}`], ["squads", "Squads"], ["fixtures", "Fixtures"], ["results", "Results"]];
  el.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px">
      <h2 style="margin:0">Admin panel</h2><span class="small muted">${esc(ctx.user.email)} · <button class="btn ghost sm" id="so">Sign out</button></span></div>
    ${pending.length ? `<div class="note warn" style="margin-bottom:12px"><b>${pending.length} registration${pending.length > 1 ? "s" : ""} waiting for your approval.</b></div>` : ""}
    <div class="tabs" role="tablist">${tabs.map(([k, l]) => `<button role="tab" data-tab="${k}" class="${tab === k ? "on" : ""}" aria-selected="${tab === k}">${l}</button>`).join("")}</div>
    <div id="tabbody"></div>`;
  $("#so", el).addEventListener("click", async () => { await data.signOut(); ctx.go("#/"); });
  $$("[data-tab]", el).forEach((b) => b.addEventListener("click", () => { tab = b.dataset.tab; rerender(); }));
  const body = $("#tabbody", el);
  const env = { regs, players, fixtures, rerender };
  ({ regs: tabRegs, squads: tabSquads, fixtures: tabFixtures, results: tabResults }[tab])(body, env);
}

// ---- registrations ----
function regCard(r, players, withActions) {
  const n = squadOf(players, r.team).length;
  const full = n >= MAX;
  return `<article class="card"><div class="reg">
    ${safeImg(r.photo) ? `<a href="${safeImg(r.photo)}" target="_blank" rel="noopener"><img src="${safeImg(r.photo)}" alt="Photo of ${esc(r.name)}"></a>` : `<div></div>`}
    <div><h3>${esc(r.name)}</h3>
      <div class="small muted">${esc(r.phone)} · ${esc(r.email)}</div>
      <div style="display:flex;align-items:center;gap:8px;margin:6px 0">${badge(r.team, 24)}<b>${esc(teamById[r.team]?.name || r.team)}</b> <span class="pill ${full ? "bad" : ""}">${n}/${MAX}${full ? " full" : ""}</span></div>
      <div class="small muted">${new Date(r.createdAt).toLocaleString("en-GB", { timeZone: LEAGUE.timezone })} ${!withActions ? " · " + esc(r.status) : ""}</div></div>
    ${withActions ? `<div class="acts"><button class="btn sm" data-approve="${esc(r.uid)}" ${full ? "disabled" : ""}>Approve</button><button class="btn bad sm" data-reject="${esc(r.uid)}">Reject</button>${full ? `<span class="small" style="color:var(--bad);align-self:center">Team is full — reject, or remove a player first.</span>` : ""}</div>` : ""}
  </div></article>`;
}

function tabRegs(el, { regs, players, rerender }) {
  const pend = regs.filter((r) => r.status === "pending").sort((a, b) => a.createdAt - b.createdAt);
  const done = regs.filter((r) => r.status !== "pending").sort((a, b) => b.createdAt - a.createdAt);
  el.innerHTML = `<h3 style="margin-bottom:10px">Waiting for approval</h3>
    ${pend.length ? `<div class="grid g2">${pend.map((r) => regCard(r, players, true)).join("")}</div>` : `<div class="empty">Nothing waiting. New registrations appear here and are emailed to you.</div>`}
    ${done.length ? `<h3 style="margin:22px 0 10px">Already decided</h3><div class="grid g2">${done.map((r) => regCard(r, players, false)).join("")}</div>` : ""}`;
  $$("[data-approve]", el).forEach((b) => b.addEventListener("click", async () => {
    b.disabled = true;
    try { await data.approveRegistration(b.dataset.approve); toast("Player approved and added to the squad."); }
    catch (e) { toast(e.message, true); }
    rerender();
  }));
  $$("[data-reject]", el).forEach((b) => b.addEventListener("click", async () => {
    const reason = window.prompt("Reason for rejecting (optional, the player will see it):", "");
    if (reason === null) return;
    try { await data.rejectRegistration(b.dataset.reject, reason.trim()); toast("Registration rejected."); } catch (e) { toast(e.message, true); }
    rerender();
  }));
}

// ---- squads ----
function tabSquads(el, { players, rerender }) {
  el.innerHTML = `<div class="grid g2">${TEAMS.map((t) => {
    const sq = squadOf(players, t.id);
    return `<article class="card"><div class="teamhead">${badge(t.id, 40)}<div><h3>${esc(t.name)}</h3><span class="pill ${sq.length >= MAX ? "ok" : ""}">${sq.length}/${MAX}${sq.length >= MAX ? " · closed" : ""}</span></div></div>
      ${sq.length ? `<div class="squad">${sq.map((p) => `<div class="pl">${photoTag(p.photo, p.name)}${esc(p.name)}<br><button class="btn bad sm" style="margin-top:4px;min-height:30px;padding:0 10px" data-remove="${esc(p.uid)}" data-name="${esc(p.name)}">Remove</button></div>`).join("")}</div>` : `<p class="muted small">No players yet.</p>`}</article>`;
  }).join("")}</div>`;
  $$("[data-remove]", el).forEach((b) => b.addEventListener("click", async () => {
    if (!window.confirm(`Remove ${b.dataset.name} from the squad? Their spot will reopen.`)) return;
    try { await data.removePlayer(b.dataset.remove); toast("Player removed."); } catch (e) { toast(e.message, true); }
    rerender();
  }));
}

// ---- fixtures ----
function fixtureDialog(fx, rerender) {
  const date = fx?.kickoff ? dayKey(fx.kickoff) : "";
  const time = fx?.kickoff ? timeValue(fx.kickoff) : "09:00:00";
  const opts = (sel) => `<option value="">Choose…</option>${TEAMS.map((t) => `<option value="${t.id}" ${sel === t.id ? "selected" : ""}>${esc(t.name)}</option>`).join("")}`;
  dialog(`<form method="dialog" class="f" id="ff" style="max-width:none" novalidate>
    <h3>${fx ? "Edit fixture" : "Schedule a fixture"}</h3>
    <div class="row"><label>Home team<select name="home">${opts(fx?.homeId)}</select></label><label>Away team<select name="away">${opts(fx?.awayId)}</select></label></div>
    <div class="row"><label>Date<input type="date" name="date" value="${date}" required></label><label>Kick-off time<input type="time" step="1" name="time" value="${time}" required></label></div>
    <div class="row"><label>Match<select name="round"><option value="">—</option>${[1, 2, 3, 4].map((n) => `<option value="${n}" ${fx?.round === n ? "selected" : ""}>${roundName(n)}</option>`).join("")}</select></label><label>Venue<input type="text" name="venue" maxlength="60" value="${esc(fx?.venue || "")}" placeholder="e.g. Main pitch"></label></div>
    <div id="derr" class="note bad" hidden></div>
    <div class="row"><button class="btn" type="submit">Save fixture</button><button class="btn ghost" type="button" data-close>Cancel</button></div>
  </form>`, (d) => {
    $("#ff", d).addEventListener("submit", async (e) => {
      e.preventDefault();
      const f = e.target, err = $("#derr", d);
      if (!f.home.value || !f.away.value) return (err.hidden = false, err.textContent = "Choose both teams.");
      if (f.home.value === f.away.value) return (err.hidden = false, err.textContent = "A team cannot play itself.");
      if (!f.date.value || !f.time.value) return (err.hidden = false, err.textContent = "Set the date and kick-off time.");
      const next = {
        ...(fx || { status: "scheduled", homeScore: null, awayScore: null, scorers: [] }),
        homeId: f.home.value, awayId: f.away.value, kickoff: toKickoff(f.date.value, f.time.value),
        round: f.round.value ? Number(f.round.value) : null, venue: f.venue.value.trim()
      };
      try { await data.saveFixture(next); d.close(); toast("Fixture saved."); rerender(); } catch (ex) { err.hidden = false; err.textContent = ex.message; }
    });
  });
}

function tabFixtures(el, { fixtures, rerender }) {
  const list = sortFixtures(fixtures);
  el.innerHTML = `<div class="row" style="margin-bottom:16px"><button class="btn" id="add" style="flex:0 0 auto">+ Schedule a fixture</button></div>
    <div class="card" style="margin-bottom:16px"><h3>Load the poster fixtures</h3>
      <p class="muted small" style="margin:4px 0 10px">Adds the 16 matches from the official poster (4 matches at 07:45, 08:48:45, 09:52:30 and 10:56:15, each 63 min 45 s). Pick the match day.</p>
      <div class="row"><label>Match day<input type="date" id="seeddate"></label><button class="btn ghost" id="seed" style="flex:0 0 auto">Load 16 fixtures</button></div></div>
    ${list.length ? list.map((f) => `<div class="fx" style="grid-template-columns:1fr auto 1fr">
      <div class="t h">${teamLabel(f.homeId, 26)}</div><div class="mid"><div class="score" style="font-size:20px">${f.kickoff ? esc(fmtTime(f.kickoff)) : "TBC"}</div></div><div class="t">${teamLabel(f.awayId, 26)}</div>
      <div class="meta">${f.round ? esc(roundName(f.round)) + " · " : ""}${f.kickoff ? esc(fmtDate(f.kickoff)) : ""}${f.venue ? " · " + esc(f.venue) : ""}${f.status === "finished" ? ` · Result ${f.homeScore}–${f.awayScore}` : ""}
        <div style="margin-top:6px;display:flex;gap:6px;justify-content:center"><button class="btn ghost sm" data-edit="${esc(f.id)}">Edit</button><button class="btn bad sm" data-del="${esc(f.id)}">Delete</button></div></div></div>`).join("") : `<div class="empty">No fixtures scheduled yet.</div>`}`;
  $("#add", el).addEventListener("click", () => fixtureDialog(null, rerender));
  $("#seed", el).addEventListener("click", async () => {
    const date = $("#seeddate", el).value;
    if (!date) return toast("Pick the match day first.", true);
    if (list.length && !window.confirm(`You already have ${list.length} fixtures. Add the 16 poster fixtures as well?`)) return;
    try { await data.seedFixtures(posterFixtures(date)); toast("16 fixtures added."); } catch (e) { toast(e.message, true); }
    rerender();
  });
  $$("[data-edit]", el).forEach((b) => b.addEventListener("click", () => fixtureDialog(list.find((f) => f.id === b.dataset.edit), rerender)));
  $$("[data-del]", el).forEach((b) => b.addEventListener("click", async () => {
    if (!window.confirm("Delete this fixture? Any result on it is deleted too.")) return;
    try { await data.deleteFixture(b.dataset.del); toast("Fixture deleted."); } catch (e) { toast(e.message, true); }
    rerender();
  }));
}

// ---- results ----
function resultDialog(f, players, rerender) {
  const pool = [...squadOf(players, f.homeId), ...squadOf(players, f.awayId)];
  const scorerRow = (s = {}) => `<div class="sc"><select aria-label="Scorer">${pool.length ? pool.map((p) => `<option value="${esc(p.uid)}" ${s.playerId === p.uid ? "selected" : ""}>${esc(p.name)} (${teamById[p.team].short})</option>`).join("") : `<option value="">No approved players</option>`}</select>
    <input type="text" inputmode="numeric" maxlength="3" placeholder="Min" aria-label="Minute" value="${esc(s.minute || "")}"><button type="button" class="btn bad sm" data-rm aria-label="Remove scorer">✕</button></div>`;
  dialog(`<form method="dialog" class="f" id="rf" style="max-width:none" novalidate>
    <h3>Enter result</h3>
    <div class="fx" style="margin:0"><div class="t h">${teamLabel(f.homeId, 26)}</div>
      <div class="mid inline" style="justify-content:center"><input type="number" min="0" max="99" name="hs" value="${f.homeScore ?? ""}" aria-label="${esc(teamById[f.homeId].name)} goals" required> <b>–</b> <input type="number" min="0" max="99" name="as" value="${f.awayScore ?? ""}" aria-label="${esc(teamById[f.awayId].name)} goals" required></div>
      <div class="t">${teamLabel(f.awayId, 26)}</div></div>
    <div><div style="font-weight:600;font-size:13px;margin-bottom:6px">Goal scorers (optional)</div><div id="scs">${(f.scorers || []).map(scorerRow).join("")}</div>
      <button type="button" class="btn ghost sm" id="addsc" ${pool.length ? "" : "disabled"}>+ Add scorer</button></div>
    <div id="derr" class="note bad" hidden></div>
    <div class="row"><button class="btn" type="submit">Save result</button>${f.status === "finished" ? `<button class="btn bad" type="button" id="clr">Clear result</button>` : ""}<button class="btn ghost" type="button" data-close>Cancel</button></div>
  </form>`, (d) => {
    const wire = () => $$("[data-rm]", d).forEach((b) => (b.onclick = () => b.parentElement.remove()));
    wire();
    $("#addsc", d).addEventListener("click", () => { $("#scs", d).insertAdjacentHTML("beforeend", scorerRow()); wire(); });
    $("#clr", d)?.addEventListener("click", async () => {
      await data.saveFixture({ ...f, status: "scheduled", homeScore: null, awayScore: null, scorers: [] });
      d.close(); toast("Result cleared."); rerender();
    });
    $("#rf", d).addEventListener("submit", async (e) => {
      e.preventDefault();
      const form = e.target, err = $("#derr", d);
      const hs = parseInt(form.hs.value, 10), as = parseInt(form.as.value, 10);
      if (!(hs >= 0) || !(as >= 0)) return (err.hidden = false, err.textContent = "Enter both scores (0 or more).");
      const scorers = $$(".sc", d).map((row) => {
        const p = pool.find((x) => x.uid === $("select", row).value);
        return p ? { playerId: p.uid, name: p.name, teamId: p.team, minute: $("input", row).value.trim() } : null;
      }).filter(Boolean);
      const hg = scorers.filter((s) => s.teamId === f.homeId).length, ag = scorers.filter((s) => s.teamId === f.awayId).length;
      if (hg > hs || ag > as) return (err.hidden = false, err.textContent = "More goal scorers than goals scored. Check the scores or remove a scorer.");
      try { await data.saveFixture({ ...f, status: "finished", homeScore: hs, awayScore: as, scorers }); d.close(); toast("Result saved. The table is updated."); rerender(); }
      catch (ex) { err.hidden = false; err.textContent = ex.message; }
    });
  });
}

function tabResults(el, { fixtures, players, rerender }) {
  const list = sortFixtures(fixtures);
  el.innerHTML = list.length ? list.map((f) => `<div class="fx"><div class="t h">${teamLabel(f.homeId, 26)}</div>
    <div class="mid">${f.status === "finished" ? `<div class="score">${f.homeScore} – ${f.awayScore}</div>` : `<div class="score" style="font-size:20px">${f.kickoff ? esc(fmtTime(f.kickoff)) : "TBC"}</div>`}</div>
    <div class="t">${teamLabel(f.awayId, 26)}</div>
    <div class="meta">${f.round ? esc(roundName(f.round)) + " · " : ""}${f.kickoff ? esc(fmtDate(f.kickoff)) : ""}
      <div style="margin-top:6px"><button class="btn ${f.status === "finished" ? "ghost" : ""} sm" data-res="${esc(f.id)}">${f.status === "finished" ? "Edit result" : "Enter result"}</button></div></div></div>`).join("")
    : `<div class="empty">Schedule fixtures first, then enter their results here.</div>`;
  $$("[data-res]", el).forEach((b) => b.addEventListener("click", () => resultDialog(list.find((f) => f.id === b.dataset.res), players, rerender)));
}
