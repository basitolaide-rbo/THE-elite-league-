// Emails the admin whenever someone registers (EmailJS free plan, called straight from the browser).
// Failure never blocks a registration: it is saved first and always shows in the admin panel.
import { EMAILJS, ADMIN_EMAIL } from "./config.js";
import { teamById } from "./teams.js";

export const emailConfigured = () => Boolean(EMAILJS.publicKey && EMAILJS.serviceId && EMAILJS.templateId);

export async function notifyAdmin(reg) {
  if (!emailConfigured()) return { sent: false, reason: "not-configured" };
  const adminUrl = new URL("#/admin", location.href).href;
  try {
    const res = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        service_id: EMAILJS.serviceId,
        template_id: EMAILJS.templateId,
        user_id: EMAILJS.publicKey,
        template_params: {
          to_email: ADMIN_EMAIL,
          player_name: reg.name,
          player_phone: reg.phone,
          player_email: reg.email,
          team: teamById[reg.team]?.name || reg.team,
          registered_at: new Date(reg.createdAt).toLocaleString("en-GB", { timeZone: "Africa/Lagos" }),
          admin_link: adminUrl
        }
      })
    });
    return { sent: res.ok };
  } catch {
    return { sent: false, reason: "network" };
  }
}
