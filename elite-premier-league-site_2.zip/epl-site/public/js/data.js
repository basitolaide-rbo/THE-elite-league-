// Picks the live Firebase backend when keys are present, otherwise the in-browser demo backend.
import { FIREBASE_CONFIG } from "./config.js";

const live = Boolean(FIREBASE_CONFIG.apiKey && FIREBASE_CONFIG.projectId);
const be = live ? await import("./backend-firebase.js") : await import("./backend-demo.js");

export const {
  mode, onAuth, signInGoogle, signInAdmin, signOut,
  getPlayers, getMyRegistration, getRegistrations, submitRegistration,
  approveRegistration, rejectRegistration, removePlayer,
  getFixtures, saveFixture, deleteFixture, seedFixtures
} = be;
