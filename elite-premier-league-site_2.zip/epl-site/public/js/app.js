import * as data from "./data.js";
import * as pages from "./pages.js";
import { admin } from "./admin.js";
import { esc, $, $$ } from "./ui.js";

const ROUTES = {
  "/": pages.home, "/fixtures": pages.fixtures, "/table": pages.table, "/teams": pages.teams,
  "/stats": pages.stats, "/rules": pages.rules, "/install": pages.install,
  "/register": pages.register, "/account": pages.account, "/admin": admin
};
const NAV = [["/", "Home"], ["/fixtures", "Fixtures"], ["/table", "Table"], ["/teams", "Teams"], ["/stats", "Stats"], ["/rules", "Rules"], ["/register", "Register", "cta"]];

const ctx = { user: undefined, go: (h) => { location.hash = h; } };
const view = $("#view");
let seq = 0;

function path() { return (location.hash.replace(/^#/, "") || "/").split("?")[0]; }

function drawNav() {
  const p = path();
  $("#nav").innerHTML = NAV.map(([href, label, cls]) => `<a href="#${href}" class="${cls || ""} ${p === href ? "on" : ""}" ${p === href ? 'aria-current="page"' : ""}>${esc(label)}</a>`).join("");
}

async function render() {
  const mine = ++seq;
  drawNav();
  if (ctx.user === undefined) return; // wait for the first auth answer
  const fn = ROUTES[path()] || ROUTES["/"];
  view.innerHTML = `<p class="loading">Loading…</p>`;
  try {
    await fn(view, ctx);
    if (mine === seq) window.scrollTo({ top: 0 });
  } catch (e) {
    console.error(e);
    if (mine === seq) view.innerHTML = `<div class="note bad"><b>Something went wrong.</b> ${esc(e.message || "Please refresh and try again.")}</div>`;
  }
}

if (data.mode === "demo") $("#demo-banner").hidden = false;
window.addEventListener("hashchange", render);
data.onAuth((u) => { const first = ctx.user === undefined; ctx.user = u; render(); if (first) $("#nav").dataset.ready = "1"; });

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}
