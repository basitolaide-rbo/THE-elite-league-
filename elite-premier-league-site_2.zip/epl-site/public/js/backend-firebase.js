// Live backend: Firebase Authentication + Cloud Firestore.
import { FIREBASE_CONFIG, ADMIN_EMAIL, LEAGUE } from "./config.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/13.0.0/firebase-app.js";
import {
  getAuth, onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signInWithRedirect,
  signInWithEmailAndPassword, signOut as fbSignOut
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-auth.js";
import {
  getFirestore, collection, doc, getDoc, getDocs, setDoc, deleteDoc, writeBatch, query, where
} from "https://www.gstatic.com/firebasejs/13.0.0/firebase-firestore.js";

const app = initializeApp(FIREBASE_CONFIG);
const auth = getAuth(app);
const db = getFirestore(app);

const toUser = (u) => u && ({
  uid: u.uid,
  email: u.email || "",
  name: u.displayName || (u.email || "").split("@")[0],
  isAdmin: (u.email || "").toLowerCase() === ADMIN_EMAIL.toLowerCase()
});

export const mode = "firebase";

export function onAuth(cb) {
  return onAuthStateChanged(auth, (u) => cb(toUser(u)));
}

export async function signInGoogle() {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: "select_account" });
  try {
    await signInWithPopup(auth, provider);
  } catch (e) {
    if (e.code === "auth/popup-blocked" || e.code === "auth/operation-not-supported-in-this-environment") {
      await signInWithRedirect(auth, provider);
    } else if (e.code !== "auth/popup-closed-by-user" && e.code !== "auth/cancelled-popup-request") {
      throw e;
    }
  }
}

export async function signInAdmin(email, password) {
  if (email.trim().toLowerCase() !== ADMIN_EMAIL.toLowerCase()) throw new Error("This account is not allowed in the admin panel.");
  try {
    await signInWithEmailAndPassword(auth, email.trim(), password);
  } catch (e) {
    throw new Error("Wrong email or password.");
  }
}

export const signOut = () => fbSignOut(auth);

const all = async (name) => (await getDocs(collection(db, name))).docs.map((d) => ({ id: d.id, ...d.data() }));

export async function getPlayers() {
  return (await all("players")).map((p) => ({ ...p, uid: p.id }));
}

export async function getMyRegistration(uid) {
  const s = await getDoc(doc(db, "registrations", uid));
  return s.exists() ? { uid, ...s.data() } : null;
}

export async function getRegistrations() {
  return (await all("registrations")).map((r) => ({ ...r, uid: r.id }));
}

export async function submitRegistration(user, data) {
  const reg = {
    uid: user.uid, email: user.email, googleName: user.name,
    name: data.name, phone: data.phone, team: data.team, photo: data.photo,
    status: "pending", createdAt: Date.now()
  };
  await setDoc(doc(db, "registrations", user.uid), reg);
  return reg;
}

export async function approveRegistration(uid) {
  const regRef = doc(db, "registrations", uid);
  const snap = await getDoc(regRef);
  if (!snap.exists()) throw new Error("Registration not found.");
  const r = snap.data();
  const squad = await getDocs(query(collection(db, "players"), where("team", "==", r.team)));
  if (squad.size >= LEAGUE.playersPerTeam && !squad.docs.some((d) => d.id === uid)) {
    throw new Error(`That team already has ${LEAGUE.playersPerTeam} players. Reject this registration or remove a player first.`);
  }
  const b = writeBatch(db);
  b.set(doc(db, "players", uid), { name: r.name, team: r.team, photo: r.photo, approvedAt: Date.now() });
  b.update(regRef, { status: "approved", decidedAt: Date.now() });
  await b.commit();
}

export async function rejectRegistration(uid, reason = "") {
  const b = writeBatch(db);
  b.update(doc(db, "registrations", uid), { status: "rejected", reason, decidedAt: Date.now() });
  b.delete(doc(db, "players", uid));
  await b.commit();
}

export async function removePlayer(uid) {
  const b = writeBatch(db);
  b.delete(doc(db, "players", uid));
  b.update(doc(db, "registrations", uid), { status: "removed", decidedAt: Date.now() });
  await b.commit();
}

export const getFixtures = () => all("fixtures");

export async function saveFixture(fx) {
  const ref = fx.id ? doc(db, "fixtures", fx.id) : doc(collection(db, "fixtures"));
  const { id, ...rest } = fx;
  await setDoc(ref, rest, { merge: true });
  return ref.id;
}

export const deleteFixture = (id) => deleteDoc(doc(db, "fixtures", id));

export async function seedFixtures(list) {
  for (let i = 0; i < list.length; i += 400) {
    const b = writeBatch(db);
    list.slice(i, i + 400).forEach((fx) => b.set(doc(collection(db, "fixtures")), fx));
    await b.commit();
  }
}
