// ELITE PREMIER LEAGUE — site settings.
// Fill in the Firebase block (README.md, step 3). While apiKey is empty the site runs in DEMO MODE
// (data kept only in the visitor's own browser) so you can try everything before setting up Firebase.

export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyAo3u4J5eqfQdOpx2S2a4O3gHPWnm5-w-U",
  authDomain: "the-elite-league.firebaseapp.com",
  projectId: "the-elite-league",
  storageBucket: "the-elite-league.firebasestorage.app",
  messagingSenderId: "752948181059",
  appId: "1:752948181059:web:cfa0ebb51446c278cebcf6"
};

// The ONLY account allowed into /admin.
export const ADMIN_EMAIL = "solomonoladimeji18@gmail.com";

// Email notifications to the admin on every new registration (free EmailJS account, README step 5).
// Leave empty to skip; registrations still appear in the admin panel either way.
export const EMAILJS = {
  publicKey: "",
  serviceId: "",
  templateId: ""
};

export const LEAGUE = {
  name: "Elite Premier League",
  season: "2026",
  playersPerTeam: 8,
  matchMinutes: 63,
  matchSeconds: 45,
  timezone: "Africa/Lagos"
};
